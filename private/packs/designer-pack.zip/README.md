# Designer Skills Pack

A practical set of briefs, checks and production steps for visual work.

## Install

Each directory under `skills/` is an independent agent skill.

- **Claude Code:** copy each skill directory to `~/.claude/skills/`, then start a new session.
- **Codex:** copy each skill directory to `~/.agents/skills/` or the skill root configured for your Codex installation, then start a new session.
- **Any agent:** give it the relevant `SKILL.md` as task context. Ask it to follow the steps and cite its assumptions.

Windows: `~` means your user home directory. Keep the directory name and its `SKILL.md` together.

## Included

- `book-cover-design`
- `brand-identity`
- `premium-spreadsheet`
- `animation-vfx`

## Start

Use `EXAMPLE-PROMPTS.md` to begin. Replace bracketed fields and supply real project material. Check output against the cited sources and your own facts before publishing.

The one-page `QUICK-GUIDE.pdf` is a printable overview. Licence terms are in `LICENSE`.
