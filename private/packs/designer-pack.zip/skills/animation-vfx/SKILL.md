---
name: animation-vfx
description: Plan, prompt and review animation, motion graphics and visual effects: character and object motion, timing and spacing, AI video prompts (Higgsfield, Kling, Veo, Wan), game VFX, lighting and colour for renders and shots. Use when animating pins, ads, book trailers, game characters or UI, when an AI video looks floaty or fake, or when lighting/colour of a render or generated image feels flat. Built from Richard Williams (The Animator's Survival Kit), Thomas & Johnston (The Illusion of Life), Jeremy Birn/Brinkmann (Digital Lighting & Rendering; The Art and Science of Digital Compositing), the VES Handbook of Visual Effects and James Gurney (Color and Light). Pairs with `video-editing` and `game-feel-ux`.
metadata:
  version: 1.0.0
---

# Animation and VFX

## 1. The 12 principles (Thomas & Johnston) as a checklist
| Principle | What to check |
|---|---|
| Squash & stretch | Mass is kept while shape deforms; nothing rubbery unless intended |
| Anticipation | A small opposite move before the main action (wind-up, crouch before jump) |
| Staging | One idea per shot, readable in silhouette |
| Straight-ahead vs pose-to-pose | Key poses first for acting; straight-ahead for fire, water, chaos |
| Follow-through & overlap | Hair, cloth, tails and appendages settle after the body stops |
| Slow in / slow out | Ease into and out of key poses; linear motion looks mechanical |
| Arcs | Natural motion travels on arcs, not straight lines |
| Secondary action | Supports the main action without stealing it |
| Timing | Number of frames = weight and mood (heavy = slower in, faster impact) |
| Exaggeration | Push poses past real to read clearly, consistent with the style |
| Solid drawing / form | Volumes stay consistent in 3D space |
| Appeal | Clear, pleasing design; charisma, not just cuteness |

## 2. Timing and spacing (Williams)
- **Timing** = how many frames an action takes; **spacing** = how far it moves between frames. Close spacing = slow; wide spacing = fast.
- Work on **2s** (12 fps holds) for snappy stylised motion, **1s** for fast action and camera moves.
- Walk cycles: contact → down → passing → up; the body rises and falls; weight shows in the down pose.
- Keep **one strong key pose** readable as a still; if the stills don't read, the motion won't.

## 3. AI video prompts (our pipeline)
Structure: `subject + action (one) + camera move (one) + lens/framing + lighting + style + duration`.
- One action and one camera move per clip; chaining motions produces mush.
- Name the principle you want: "slow push-in, ease in and out", "weighty footsteps with anticipation", "cloth follows through after she stops".
- Start from a strong still (image-to-video) with the final composition; motion can't fix weak staging.
- Reject clips with morphing hands/faces, sliding feet, text warping, or physics that breaks mass. Re-roll with simpler action rather than a longer prompt.

## 4. Light and colour (Gurney, Birn)
- **Light defines form:** key light (main, sets mood), fill (lifts shadows), rim/back light (separates subject from background). Decide the key direction before anything else.
- **Value first:** a shot must read in greyscale. Limit to 3-4 value groups.
- **Colour temperature contrast:** warm light → cool shadows (and vice versa). Gamut-limit the palette (pick a triangle on the colour wheel) for harmony.
- **Atmospheric perspective:** distance lowers contrast and shifts colour towards the sky/fog tone.
- Gurney's colour accents: one saturated note in a mostly muted image directs the eye.

## 5. Compositing and VFX (Brinkmann, VES)
- **Match the plate:** black levels, light direction, colour temperature, grain/noise, lens blur and motion blur must match between elements.
- Edges sell composites: soft, light-wrapped edges beat hard cut-outs.
- Integrate with **contact shadows** and reflections.
- Plan VFX in previs: what is practical, what is generated, what is composited; shoot/generate clean plates.
- Game VFX: readable silhouette first, then colour; anticipation → impact → dissipation timing; keep particle counts within the frame budget (see `game-programming`).

## Review checklist
- [ ] Key poses read as stills and in silhouette
- [ ] Easing, arcs and follow-through present
- [ ] One action and one camera move per AI clip
- [ ] Shot reads in greyscale; light direction consistent
- [ ] Composited elements match black levels, grain and blur

## Sources
Thomas & Johnston, *The Illusion of Life* (12 principles). Williams, *The Animator's Survival Kit* (timing, spacing, walks, keys). Birn, *Digital Lighting & Rendering*; Brinkmann, *The Art and Science of Digital Compositing* (matching, edges, integration). VES, *The VES Handbook of Visual Effects* (VFX planning, previs). Gurney, *Color and Light* (form lighting, temperature, gamut, atmosphere). Summarised in our own words.
