---
name: brand-identity
description: Build or review a brand identity for a product, sub-brand, game or series: name check, positioning line, logo/wordmark brief, palette, type pair, voice, and a one-page brand sheet agents can follow. Use when launching a new product line, making a logo or wordmark prompt, unifying a series (books, games, apps), auditing whether pages "look like us", or briefing Canva/Higgsfield/ComfyUI. Built from Alina Wheeler (Designing Brand Identity), Paul Rand (A Designer's Art / Design, Form and Chaos) and Michael Bierut (How to). Pairs with `book-cover-design` and a separate copy review.
metadata:
  version: 1.0.0
---

# Brand identity

A brand is what people **remember and expect** from us. The identity (name, mark, colour, type, voice) is how we make that memory consistent at every touchpoint (Wheeler).

## 1. Strategy before visuals (Wheeler)
Write these five lines first; no logo work until they exist:
1. **Who it's for:** one sentence about the person and the moment they need us.
2. **What it does for them:** the outcome, not the feature.
3. **Why us:** the one differentiator we can prove.
4. **Personality:** three adjectives, plus three it is *not* (e.g. calm, practical, warm / not mystical, not clinical, not hype).
5. **Promise line:** ≤8 words a stranger understands.
Wheeler's ideals to check against: vision, meaning, authenticity, differentiation, durability, coherence, flexibility, commitment, value.

## 2. Name check
Short, sayable, spellable after hearing it once; available as a domain/handle; no clash with a trademark in the same class (search before use; the human files any trademark). Prefer suggestive names (Noctune) over descriptive ones that can't grow, or abstract ones that need a big budget to explain.

## 3. The mark (Rand, Bierut)
- **Simple enough to draw from memory.** Rand: a logo identifies, it doesn't explain; meaning accrues through use. Don't cram the product story into it.
- **Works in one colour, at 16 px (favicon) and on a billboard.** Test black-on-white, white-on-black, and at favicon size before approving.
- **Type of mark:** wordmark (most of our products: cheapest, clearest), lettermark/monogram (long names), symbol + wordmark (apps and games that need an icon).
- **Find the idea in the name** (Bierut): a letterform, a shape or a double meaning hiding in the name usually beats an imported symbol.
- Present 2-3 directions max, each with its rationale in one sentence.

## 4. System
- **Palette:** one primary, one accent, neutrals; give hex values plus contrast ratios (WCAG AA for text). Our master brand: deep teal/ink with acid accent (see site globals.css). Sub-brands may own one accent colour.
- **Type pair:** one display face with character + one readable text face. Same faces across the series.
- **Imagery rules:** photo vs illustration, lighting, what we never show.
- **Voice:** honest, warm, plain; banned words list (check claims against supplied evidence).
- **Repetition makes recognition:** same positions, colours and type on every cover, page, ad and thumbnail.

## 5. Output: one-page brand sheet
Save as `<product>/BRAND.md`: strategy lines · name note · mark files and usage (clear space, min size, don'ts) · palette with hex · type pair · imagery rules · voice + banned words · 3 example applications (cover, ad, social avatar). Agents read this before making any asset for that product.

## Review checklist
- [ ] Strategy lines written before visuals
- [ ] Mark legible at 16 px and in one colour
- [ ] Palette passes AA contrast for text
- [ ] Consistent with the existing brand where appropriate, distinct where needed
- [ ] BRAND.md saved and linked from the product README

## Sources
Wheeler, *Designing Brand Identity* (brand ideals, process, touchpoints, brand standards). Rand (logo as identifier, simplicity, meaning through use). Bierut, *How to* (finding the idea in the problem/name, presenting work). Summarised in our own words.
