---
name: book-cover-design
description: Design or brief a book, guide or workbook cover (and any product pack shot or thumbnail) that reads at thumbnail size and sells the content. Use when making covers, writing image-model prompts for covers, reviewing a cover, choosing cover typefaces, tracking, hierarchy or colour, or turning a cover into a store or YouTube-style thumbnail. Built from Chip Kidd (Go), Ellen Lupton (Thinking with Type), Jim Williams (Type Matters), John Kane (A Type Primer), Steve Schoger (Refactoring UI) and Heller & Anderson (The Graphic Design Idea Book), plus Robin Williams (The Non-Designer's Design Book), Timothy Samara (Making and Breaking the Grid), Kidd (Judge This), Peter Mendelsund (Cover; What We See When We Read) and Erik Spiekermann (Stop Stealing Sheep).
metadata:
  version: 1.1.0
---

# Book cover design

A cover has one job: make the right reader stop, understand what the book is, and want it, in under a second and often at **160 px wide** in a store grid. Everything below serves that.

## 1. Content, then concept, then form (Kidd)
1. **Content:** read the brief and listing. In one sentence: who is it for, and what changes for them? List 3-5 concrete nouns from the book (objects, places, actions).
2. **Concept:** find ONE visual idea that bridges content and form: a metaphor, an object, a crop or a typographic gesture. Kidd's test: *clarity or mystery?* Instructional and study guides need **clarity**. Fiction and self-reflection can carry a little **mystery**.
3. **Form:** only now pick image, type, colour and layout. A concept gives each visual choice a purpose (Kidd).
- Write the concept in one line before generating anything: *"A single chess knight casting a long shadow shaped like a question mark: decisions under uncertainty."*

## 2. Hierarchy: one dominant thing (Lupton, Schoger)
- Rank everything: **1 title → 2 image/concept → 3 subtitle/series → 4 brand.** Nothing else.
- Use **strong scale contrast**. Small size differences can weaken hierarchy (Lupton). The title is typically **2.5-4×** the subtitle size.
- **Emphasise by de-emphasising** (Schoger): make secondary lines smaller, lighter or lower-contrast rather than making the title louder.
- **Greyscale test** (Schoger): the cover must work in greyscale. If the title disappears without colour, the hierarchy is wrong.
- **Thumbnail test:** shrink to 160 px wide. The title must still read, the concept must still be recognisable, and the subtitle may blur.

## 3. Type
- **Choose the face for the message** (Williams). Study and finance: confident grotesk or modern serif. Calm and reflective: humanist serif. Technical: geometric or grotesk sans. Children: rounded and warm.
- **Two typefaces maximum**, mixed for contrast (serif + sans, light + bold), (Lupton). One family at several weights is often enough.
- **Tracking:**
  - **ALL CAPS and small caps: add tracking** (+3% to +10%). Letters of equal height need space to stay distinguishable (Schoger, Kane, Williams).
  - **Large lowercase display titles: tight to neutral** (−2% to 0). Headline faces are drawn with tight spacing (Schoger).
  - **Light type on dark: track slightly looser** for legibility (Lupton).
  - Never letterspace lowercase body text (Kane).
  - **Wide tracking signals elegance** (Kidd); use it for series lines and brand marks, not long titles.
- **Line breaks by meaning**, not by fit: "THE HEADACHE / TRIGGER MAP", never "THE HEADACHE TRIGGER / MAP".
- **Optical over mathematical:** visually centre lines, kern display pairs (AV, To, Wa), and hang punctuation (Williams).
- Avoid fake small caps, stretched or condensed type, outlines, bevels and drop shadows used only to rescue weak contrast.

## 4. Image and composition (Kidd, Heller & Anderson)
- **Scale:** one object large is stronger than many objects small. **Crop** boldly; a partial object invites the eye to complete it.
- **Repetition and pattern** make a fast, ownable texture (series covers).
- **Positive/negative space:** leave a clean field for the title. Never fight the image for the same area.
- **Where the eye starts:** top-left and top. Put the title in the first reading position unless the concept demands otherwise.
- **Series consistency:** one grid, one type system and one brand position across a range; vary colour and concept per title.

## 5. Colour
- A **2-3 colour palette plus one accent**. Colour carries mood before any word is read (Kidd).
- **Value contrast** (light vs dark) matters more than hue contrast for the title. Check that title/background contrast reads at thumbnail size.
- Use genre colour codes deliberately: calm (muted blues and greens), urgency (warm reds and oranges), finance (deep navy, green, gold), science and tech (ink plus one electric accent).

## 6. Writing image-model prompts for covers
Image models typeset badly unless told exactly what to do. Always specify:
1. Format: "Book cover, 2:3 portrait, flat front cover (no 3D book mockup unless asked)".
2. **Exact text, quoted, and nothing else**: title, subtitle, series or brand. "No other words, letters or numbers anywhere."
3. Type direction: category (grotesk sans, modern serif…), weight, case, **tracking** ("all caps, tracked +8%"), alignment and position ("title in the top third, left-aligned").
4. The **one concept** as a concrete image, its scale and crop.
5. Palette (2-3 named colours + accent) and value contrast ("off-white title on deep navy").
6. Hierarchy ("title dominant, subtitle at about a third of title size, brand small at the bottom").
7. Exclusions: "no gradients behind text, no extra badges, no fake publisher logos, no quotes, no stars, no awards".
Then check every output for: spelling (letter by letter), extra invented text, title legible at 160 px, and the concept readable.

## 6b. Layout basics and first impressions (added v1.1)
- **CRAP (Robin Williams):** *Contrast* (if two things differ, make them very different; timid contrast looks like a mistake), *Repetition* (repeat one colour, rule or type treatment so the series looks related), *Alignment* (every element lines up with something; pick **one** alignment per cover, never centre-plus-flush-left), *Proximity* (group what belongs together: title and subtitle close, author apart).
- **Grid (Samara):** build on a simple grid (margins plus 2-4 columns or a modular grid) so series covers share positions. Break the grid once, on purpose, for the focal element only.
- **First-impression test (Kidd, Judge This):** look at the cover for one second, then look away. What do you remember? If it isn't the title or the concept, the hierarchy is wrong. Decide deliberately between **clarity** (say exactly what it is: guides, workbooks, non-fiction) and **mystery** (provoke a question: fiction, story-led books). For instructional products, start with clarity.
- **Interpret, don't illustrate (Mendelsund):** the cover is a reading of the book, not a scene from it. Prefer one metaphor or object that stands for the whole idea over a literal picture of the contents. Leave room for the reader's imagination.
- **Typeface carries voice (Spiekermann):** a bland default face makes the brand invisible. Pick a face whose personality matches the message (warm humanist for wellness, sturdy grotesk for practical, high-contrast serif for premium), and keep it consistent across the series.

## 7. Review checklist (score 1-5 each, ship at 4+ average, no 1s)
| | Question |
|---|---|
| Concept | Is there one clear idea that a stranger could describe? |
| Hierarchy | Title, then image, then subtitle, then brand: is the order obvious? |
| Thumbnail | Readable and recognisable at 160 px? |
| Type | ≤2 faces, appropriate to the message, tracking right for the case? |
| Colour | Limited palette, strong value contrast on the title? |
| Honesty | No invented badges, reviews, awards or claims? Text spelled exactly? |
| Layout | One alignment, clear grouping, strong contrast, series grid kept? |
| First look | After a 1-second glance, is the title or concept what you remember? |
| Genre fit | Does it look like it belongs on the right shelf, while standing out from it? |

## Sources
Kidd, *Go: A Kidd's Guide to Graphic Design* (content-concept-form, scale, crop, repetition, colour, clarity vs mystery). Lupton, *Thinking with Type* (scale contrast, mixing typefaces, tracking, light-on-dark). Williams, *Type Matters* (typeface selection, display setting, visual centring, letterspacing capitals). Kane, *A Type Primer* (contrast pairs, kerning, letterspace uppercase only). Schoger, *Refactoring UI* (hierarchy, de-emphasis, greyscale first, all-caps letter-spacing). Heller & Anderson, *The Graphic Design Idea Book* (composition devices). Williams, *The Non-Designer's Design Book* (contrast, repetition, alignment, proximity). Samara, *Making and Breaking the Grid* (grid systems and deliberate breaks). Kidd, *Judge This* (first impressions, clarity vs mystery). Mendelsund, *Cover* and *What We See When We Read* (interpretation over illustration). Spiekermann, *Stop Stealing Sheep* (typeface as voice). Summary and practical adaptation of the cited books.
