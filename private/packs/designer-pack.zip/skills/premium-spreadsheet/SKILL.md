---
name: premium-spreadsheet
description: Build sellable Excel and Google Sheets templates (trackers, planners, budgets, logs, dashboards) that work in both apps without formula errors, look designed rather than default, and sell the outcome rather than "a spreadsheet". Use when making a spreadsheet product for Etsy, Gumroad, Whop or the site, converting a book's trackers into a sheet, reverse-engineering a best-selling Etsy spreadsheet, or writing its listing and mockups. Pairs with `book-cover-design` (mockups and thumbnails), `brand-identity`, `copy-strategy` and `marketing-experiments`.
metadata:
  version: 1.0.0
---

# Premium spreadsheet templates

## 1. Sell the outcome, not the file
The buyer wants a solved problem ("know exactly where my money went this month"), and the sheet is just how it arrives. Titles, thumbnails and first lines lead with the outcome and the person; "Google Sheets / Excel" goes in the format line and the keywords. Etsy is full of plain screenshots of grids; a designed mockup showing the result (a chart, a filled-in month, a phone view) stands out. Tell the maker's story: why the template exists and what problem it solved.

## 2. Pick what to build (from demand, never guesses)
- Start from evidence: Etsy best-seller listings in the niche (high review counts, recent "bestseller" badges), eRank/Everbee-style keyword data if available, and trackers from existing products, where the structure is relevant.
- Good fits: budgets and debt payoff, habit/health/symptom trackers, planners (meal, cleaning, homestead, garden, wedding, study), small-business logs (inventory, orders, mileage, invoices), teacher gradebooks/caseloads.
- One product = one job done end to end. Bundles come after singles have sold.

## 3. Build rules (compatibility first)
- Build with openpyxl (xlsx) and test that the file opens in LibreOffice headless without errors (`soffice --headless --convert-to pdf`); Google Sheets imports xlsx.
- Only functions that exist in BOTH Excel and Google Sheets: SUM, SUMIFS, COUNTIFS, AVERAGEIFS, IF, IFERROR, INDEX/MATCH, XLOOKUP is OK in both (2024+) but prefer INDEX/MATCH for older Excel, TEXT, DATE, EOMONTH, WEEKDAY, SPARKLINE is Sheets-only (skip it in xlsx). No macros/VBA, no Apps Script, no external links, no volatile INDIRECT/OFFSET chains.
- Wrap every calculated cell in IFERROR so an empty template shows blanks, not #DIV/0!.
- Data validation dropdowns for categories; conditional formatting for status (no more than 3 colours); freeze header rows; protect formula cells (unlocked input cells only); named ranges for lists.
- Structure: a "Start here" tab (how to use, 5 steps, with a screenshot), a Settings tab (categories, currency, year), input tabs, a Dashboard tab (charts built with native charts), and a hidden Calc tab if needed.
- Fill a realistic example in a separate "Example" copy, never in the buyer's blank file.

## 4. Design (Refactoring UI + CRAP + our brand)
- One accent colour + neutrals; header band in the accent; input cells subtly tinted so people know where to type; generous row height (20-22 px); one font (Inter/Arial in Sheets-safe sizes 10-11, headers 14-18).
- Hierarchy: the dashboard's single most important number is the biggest thing on screen.
- Align numbers right, text left; currency and percentage formats set; dates in one format.
- Print setup: fit to page width, landscape for wide sheets, repeat header rows.

## 5. Listing kit (per product)
1. Thumbnail 1 (2000x1600 or 2700x2025 for Etsy): outcome headline (≤6 words) + device mockup showing the dashboard; readable at 160 px (book-cover-design section 7).
2. Thumbnails 2-7: each feature as a benefit; a "what's included" panel; a how-it-works (3 steps); the compatibility panel (Excel + Google Sheets, desktop + mobile view); a short demo video (10-15 s screen recording, see video-editing).
3. Title (≤140 chars on Etsy, keywords front-loaded but readable), 13 tags, description: outcome → who it's for → what's included → how to get it (instant download + PDF with the Google Sheets copy link) → FAQ.
4. Delivery: the xlsx + a PDF with the "Make a copy" Google Sheets link + a quick-start guide. Never share an edit link.
Keep listing claims factual: do not invent reviews, rankings or savings.

## 6. QA checklist (ship only if all pass)
- [ ] Opens with no errors in Excel (LibreOffice check) and imports cleanly into Google Sheets
- [ ] Blank template shows no error values; example file shows sensible results
- [ ] Every input cell is unlocked and tinted; formulas protected
- [ ] Dashboard reads in 5 seconds; most important number is the largest
- [ ] Thumbnail passes the 160 px test; title leads with the outcome
- [ ] Start-here tab tells a new buyer what to do in 5 steps

## Sources
Schoger, *Refactoring UI* (visual hierarchy and interface design). Robin Williams, *The Non-Designer's Design Book* (contrast, repetition, alignment and proximity). Marketplace observations inform the product and listing checks. Summarised in our own words.
