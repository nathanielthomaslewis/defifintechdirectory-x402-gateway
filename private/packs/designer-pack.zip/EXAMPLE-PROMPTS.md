# Example prompts

Replace bracketed fields with your project details.

## Cover brief

Use book-cover-design to develop three cover concepts for a 2:3 guide titled [TITLE]. Audience: [AUDIENCE]. Summarise the visual metaphor, hierarchy, type direction and a 160 px thumbnail check. Use only supplied book facts.

## Brand system

Use brand-identity to draft a one-page identity for [PRODUCT]. Include positioning, mark brief, palette with accessible text colours, type pair and three applications. Mark unknown facts for confirmation.

## Spreadsheet review

Use premium-spreadsheet to review this [TEMPLATE] for input clarity, formula compatibility, dashboard hierarchy and buyer instructions. Return prioritised fixes.

## Motion brief

Use animation-vfx to turn [SCENE] into a shot brief with key poses, timing, lighting and compositing checks.

