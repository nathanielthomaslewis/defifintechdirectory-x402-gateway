---
name: game-feel-ux
description: Make a game feel good to control and easy to understand. Use when tuning movement, jumps, hits, camera, input response, juice and feedback, or designing onboarding, HUD, menus, tutorials and accessibility; and when playtesters say it feels floaty, stiff, confusing or "not fun yet". Built from Steve Swink (Game Feel) and Celia Hodent (The Gamer's Brain). Pairs with `game-design` and `level-design`.
metadata:
  version: 1.0.0
---

# Game feel and game UX

## Part A: game feel (Swink)
Game feel = **real-time control** of a **simulated object** in a **simulated space**, with **polish** that sells the interaction.

### The six things to tune
1. **Input:** what the device can express (analogue stick vs key vs touch vs tracked hands). Design for the input you have.
2. **Response:** how input maps to motion: acceleration, top speed, deceleration, air control, turn rate. Most "floaty" or "stiff" complaints live here.
3. **Context:** the space and objects that give motion meaning (gaps to jump, walls to slide, enemies to dodge). Tuning without level context is guessing.
4. **Polish:** effects that sell physicality without changing the simulation: squash/stretch, dust, screen shake, hit-stop, camera lag, sound.
5. **Metaphor:** what the thing *is* sets expectations (a tank should feel heavy, a bee should feel darty).
6. **Rules:** goals and consequences that make the motion matter.

### Practical rules
- **Response under ~100 ms** from input to visible change; anything slower feels sluggish. On XR, lower still.
- **Expose every feel number** (gravity, jump height, coyote time, input buffer, acceleration) in a tuning resource, never hard-coded, so playtests can change them live.
- Add forgiveness: **coyote time** (~0.1 s), **jump/attack buffering** (~0.1-0.15 s), generous hitboxes for the player, strict ones for hazards.
- **Hit-stop** (2-6 frames freeze) + shake + sound on impact sells weight more than animation does.
- Tune one variable at a time against a fixed test level; record values in the playtest log.

## Part B: game UX (Hodent)
The player's brain has limited **perception, attention and memory**. Design for those limits.
- **Usability pillars:** signs and feedback (every action answered), clarity (one meaning per icon/colour), form follows function (things look like what they do), consistency, minimal workload, error prevention and recovery, flexibility (remap controls, options).
- **Engage-ability:** motivation (competence, autonomy, relatedness), emotion (game feel, surprise), and **flow** (challenge matched to skill).
- **Onboarding:** teach by doing in context, one mechanic at a time, at the moment it's needed. Text walls get skipped; players forget what they read 5 minutes ago.
- **Attention:** the eye goes to motion, contrast and faces. Put critical info where the player is already looking, and never animate unimportant UI.
- **Memory:** don't rely on players remembering. Show the controls when relevant; mark objectives on screen.
- **Playtest for UX separately:** watch first-time players with no help; note every hesitation, wrong guess and "what do I do now?". Each one is a UX bug.
- **Accessibility from M1:** remappable controls, subtitles, colour-blind-safe palettes (never colour alone), text size options, seated/one-handed modes for XR.

## Checklist before calling M2 "feels good"
- [ ] Input-to-motion under 100 ms, with buffers and coyote time set
- [ ] Feel numbers exposed and documented
- [ ] Every action has visual and audio feedback; impacts have hit-stop
- [ ] A new player completes the first loop without being told what to do
- [ ] Controls remappable; colour-blind and subtitle options present

## Sources
Swink, *Game Feel* (real-time control, simulated space, polish, metaphor, rules; tuning metrics). Hodent, *The Gamer's Brain* (perception, attention, memory; usability and engage-ability; onboarding). Summarised in our own words.
