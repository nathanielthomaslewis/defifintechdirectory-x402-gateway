---
name: xr-design
description: Design VR/AR/XR experiences that are comfortable, present and usable: locomotion, sickness mitigation, interaction (hands, controllers, gaze), UI in 3D space, scale, performance budgets and playtesting with headsets. Use for any av-xr-kit, Quest, PCVR or WebXR project, when choosing locomotion or interaction schemes, placing UI, or when testers report nausea or confusion. Built from Jason Jerald (The VR Book: Human-Centered Design for Virtual Reality). Pairs with `level-design` (XR rooms), `game-feel-ux` and `game-programming`.
metadata:
  version: 1.0.0
---

# XR design

## 1. Presence and comfort first (Jerald)
- **Presence** = the feeling of being there. It breaks on latency, tracking loss, wrong scale, inconsistent physics, or UI glued to the face.
- **Sickness** mostly comes from **vection** (seeing motion your inner ear doesn't feel), **latency**, low/unstable frame rate, and accelerations.
- Hard rules: hold the target frame rate (72/90/120 Hz) every frame; **never move or rotate the camera without the user's input**; never take head tracking away; avoid acceleration and rotation the user didn't choose.

## 2. Locomotion
| Option | Comfort | Use |
|---|---|---|
| Room-scale walking | Best | Default; design spaces to fit the play area |
| Teleport (arc + fade/blink) | High | Default artificial locomotion |
| Snap turn (30-45°) | High | Default rotation |
| Smooth move with vignette | Medium | Option for experienced users, off by default |
| Smooth turn / vehicles | Low | Only with a stable cockpit frame and options |
Always offer seated mode and comfort settings, persisted.

## 3. Interaction
- **Direct (touch/grab) beats remote (ray)** within arm's reach; use rays for distance and menus.
- Give **affordances** (things look grabbable) and **feedback** on every interaction: highlight on hover, haptic + sound on grab/press.
- Hands: forgiving grab volumes, objects snap to hand pose; never let hands pass through solid world geometry without feedback.
- Reduce fatigue: avoid "gorilla arm" (long periods with arms raised); rest interaction at waist/chest height.

## 4. UI in 3D
- **Diegetic or world-anchored** UI over head-locked UI. If something must follow the head, lag it gently (lazy follow).
- Comfortable viewing: ~1-3 m distance, within ~30° below eye line, text large enough (rule of thumb ≥1.5° visual angle per character height).
- Keep important content in the central field of view; don't require extreme head turns.

## 5. Scale and world
- Real-world scale: eye height from the user's real height or calibrated; doors ~2 m, tables ~75 cm.
- Stable horizon and reference frames (cockpit, ground) reduce sickness.
- Spatial audio cues direct attention better than arrows (see `game-audio`).

## 6. Performance budget
Frame time at 90 Hz is ~11 ms for both eyes. Budget draw calls, use foveated rendering where available, bake lighting, LODs everywhere, avoid overdraw from transparent particles. Profile on the target headset, not the PC.

## 7. Playtesting XR
Short sessions (≤15 min) with new users; ask about comfort (SSQ-style 0-3 for nausea, eye strain, disorientation) after each; watch for head/neck strain and confusion; log in the playtest file. Our headless `--xr-mode off` tests check logic only; comfort needs a headset.

## Checklist
- [ ] Frame rate held on target hardware
- [ ] No camera motion without user input; teleport + snap turn defaults
- [ ] Seated mode and comfort options persisted
- [ ] UI world-anchored, readable, inside comfortable view
- [ ] Every interaction has visual, audio and haptic feedback
- [ ] Headset playtest with comfort scores logged

## Sources
Jerald, *The VR Book* (presence, sickness theory, locomotion, interaction, UI, iterative design). Summarised in our own words.
