---
name: game-design
description: Design, scope, review or improve a game (mobile, PC, XR/VR, web, tabletop) from concept to playtest. Use when writing a game PRD/one-sheet/GDD, choosing core loop and controls, planning M1 greybox scope, designing levels or progression, balancing numbers, planning playtests, mobile/touch design, retention and monetisation, or reviewing why a game isn't fun. Built from Schell (The Art of Game Design), Fullerton (Game Design Workshop), Rogers (Level Up!, Swipe This!), Schreiber (Game Balance), Lovell (The Pyramid of Game Design), Zubek, Adams, Rouse and Brathwaite & Schreiber.
metadata:
  version: 1.0.0
---

# Game design

Make the smallest version that proves the fun, put it in front of players, and change it until they want more. Everything here serves that loop.

## 1. Start from the experience (Schell, Fullerton)
- Write the **essential experience** in one sentence: what should the player *feel*, moment to moment? ("The panic and relief of building the last wall as the wave hits.") Every later choice is judged against it (Schell's Lens of the Essential Experience).
- Name the **player experience goals** (Fullerton): 2-4 measurable ones you can check in a playtest ("players retry within 5 seconds of failing").
- Pick the **audience and context**: who, on what device, for how long per session, alone or together.

## 2. Pin down the formal elements (Fullerton)
Players · objectives · procedures (what you do) · rules · resources · conflict · boundaries · outcome.
If you can't fill all eight in a few lines, the design isn't ready to build.

## 3. The core loop and the Three Cs (Rogers, Zubek)
- **Core loop:** the 10-60 second cycle of action → feedback → reward → new decision. Draw it as a circle. If the loop isn't fun as a grey box, art won't save it.
- **The Three Cs: Character, Camera, Controls.** Lock these before content. Changing any of them late breaks everything built on top (Rogers).
- Zubek's layers: **mechanics** (rules) → **systems** (how mechanics interact) → **gameplay** (what players do) → **player experience** (what they feel). Design down the stack; debug up it.

## 4. Documents, smallest first (Rogers)
1. **One-sheet:** title, genre, platform, audience, essential experience, core loop, 3 unique selling points, comparable games.
2. **Ten-pager:** story/setting, the Three Cs, core loop, progression, key features, art/audio direction, monetisation.
3. **Beat chart:** a table of levels or sessions × (setting, new mechanic, enemies/obstacles, reward, time, colour). It shows the pacing and where each mechanic is introduced.
4. GDD only as needed. Store the one-sheet, fuller design brief and beat chart with the project.

## 5. Build: M1 greybox → playtest → content (our pipeline)
- **M1 = the core loop playable with primitives**, Three Cs final, headless tests passing (our av-game-kit / av-xr-kit standard). No final art.
- **Playtest early and often** (Fullerton): watch silently, note where players hesitate, fail or smile. Ask "what did you think you were supposed to do?", not "did you like it?".
- Change one thing at a time between tests; keep a dated playtest log.
- **Risk first** (Schell's Lens of Risk Mitigation): build the scariest unknown first (netcode, physics feel, XR comfort).

## 6. Lens checklist for reviews (subset of Schell's 111)
Ask each question of the current build:
| Lens | Question |
|---|---|
| Essential Experience | Does the build deliver the one-sentence feeling? |
| Fun / Pleasure | Which moment do players enjoy most? Can we have more of it? |
| Curiosity / Surprise | What makes players want to see what's next? |
| Problem Solving | What problems does the player solve, and are they the right difficulty? |
| Flow | Clear goals, immediate feedback, challenge matched to skill? |
| Meaningful Choices | Does every choice have a visible trade-off? (no dominant strategy) |
| Triangularity | Is there a safe low reward and a risky high reward choice? |
| Skill vs Chance | Is the mix right for this audience? |
| Feedback / Juiciness | Does every action get immediate, satisfying audio-visual feedback? |
| Visible Progress | Can players see they're getting better or further? |
| Simplicity / Elegance | Can a mechanic be removed without loss? Remove it. |
| Accessibility | Can a new player start without a manual? |
| Indirect Control | Are we guiding with level layout, light and sound rather than text? |
| Playtesting | When did real players last touch this? |

## 7. Balance (Schreiber)
- **Transitive** systems (more cost = more power): build a **cost curve** (cost vs benefit) and keep every item on or near it. Outliers are bugs or deliberate rewards.
- **Intransitive** systems (rock-paper-scissors): good for counterplay, so no single best choice exists.
- Hunt **dominant strategies**: if one option is always best, the others are noise.
- Use spreadsheets and simulated runs before tuning by feel; tune one variable at a time.

## 8. Progression, retention, money (Lovell, Rogers)
- Pacing: introduce one mechanic, let players master it, combine it, then test it (the beat chart shows this).
- **First session matters most:** the core loop within 30 seconds on mobile, within the first minute on PC/XR. Tutorials teach by doing, never by walls of text.
- **Lovell's pyramid:** most players play free or cheap; a small group of superfans will spend much more if there's something worth buying. Design what superfans value (cosmetics, expansions, creation tools) without making free players' experience worse. Never sell power that breaks fairness in competitive play.
- Measure day-1/day-7 retention before spending on traffic.

## 9. Platform rules
- **Mobile/touch (Rogers, Swipe This!):** design for one thumb in portrait unless the genre demands otherwise; big touch targets; no hover; short sessions (1-5 minutes) with a clear stopping point; the player's finger hides part of the screen, so keep critical info at the top; readable art at small sizes.
- **XR:** comfort first: no forced camera motion, teleport or snap turn options, seated play option, 72-90 fps budget, UI at arm's length; playtest on the headset, never just in the editor.
- **Web/Playables:** instant load (<5 s), no login wall, works with keyboard, mouse and touch.

## 10. Honest store pages and art
- Key art and capsules follow the `book-cover-design` skill (one concept, hierarchy, thumbnail test). Show real gameplay in screenshots and trailers; never fake features.

## See also
`game-feel-ux` (Swink, Hodent), `level-design` (Totten), `game-programming` (Nystrom, Gregory), `xr-design` (Jerald), `game-audio` (Collins, Marks), `story-structure` (McKee, Snyder).

## Sources
Schell, *The Art of Game Design* (lenses); Fullerton, *Game Design Workshop* (formal elements, playtest-driven iteration); Rogers, *Level Up!* (one-sheet, ten-pager, beat chart, Three Cs) and *Swipe This!* (touchscreen design); Schreiber, *Game Balance* (cost curves, transitive/intransitive); Lovell, *The Pyramid of Game Design* (service games, superfans); Zubek, *Elements of Game Design*; Brathwaite & Schreiber, *Challenges for Game Designers*. Summarised in our own words.
