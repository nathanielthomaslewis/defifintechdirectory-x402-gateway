---
name: game-audio
description: Design, implement and mix sound and music for games, XR, videos, ads and audio products: sound lists, adaptive/interactive music, feedback sounds, field recording, loudness targets and mixing. Use when planning a game's audio, wiring sounds in Godot, prompting Suno/ACE-Step/ElevenLabs SFX, mixing a trailer or affirmation/sleep track, or when audio feels thin, muddy or tiring. Built from Karen Collins (Game Sound), Aaron Marks (The Complete Guide to Game Audio), Ric Viers (The Sound Effects Bible) and Mike Senior (Mixing Secrets for the Small Studio). Sonnenschein (Sound Design) and Bob Katz (Mastering Audio) are being OCR'd and will be folded in. Pairs with `game-feel-ux`, `xr-design` and `video-editing`.
metadata:
  version: 1.0.0
---

# Game and product audio

## 1. Plan (Marks)
Make an **audio asset list** early: `ID · trigger · category (UI/player/enemy/ambience/music/VO) · variations · loop? · priority · status`. Audio scoped late always ends up rushed and generic.
Categories each get a bus: Master → Music, SFX (Player, World, UI), Ambience, VO.

## 2. Interactive sound (Collins)
- Game audio is **non-linear**: it responds to player action and game state. Design for repetition: every frequent sound needs **3-6 variations** plus small random pitch (±2-5%) and volume variation.
- **Feedback first:** every player action gets an immediate sound (≤50 ms). Sound sells game feel as much as animation (hit-stop + impact sound).
- **Adaptive music:** horizontal re-sequencing (switch sections at musical boundaries) or vertical layering (add/remove stems with intensity). Transition on bar lines, not mid-phrase.
- **Diegetic vs non-diegetic:** decide whether a sound exists in the world (spatialised) or is UI/score (not spatialised).
- Ambience is layered: bed (constant) + random one-shots (birds, creaks) on timers.

## 3. Sound effects (Viers)
- Record or generate **clean, dry** sources; add reverb in the engine/mix, not baked in.
- Layer to build a sound: transient (attack/click) + body (weight) + tail (texture). Big impacts = 2-4 layers.
- Name files consistently: `category_object_action_variation.wav` (e.g. `sfx_door_wood_open_03.wav`).
- Work at 48 kHz/24-bit; export to OGG for Godot/web.

## 4. Mixing (Senior)
- **Reference tracks:** compare against a professional mix in the same genre at matched loudness, constantly.
- Balance with faders first, EQ second, compression third. Mono-check the mix.
- **Cut, don't boost:** high-pass everything that doesn't need lows (most SFX, VO, UI) to clear mud below ~100-150 Hz.
- Give each element its own frequency space; carve the music under VO (sidechain/ducking 3-6 dB).
- Monitor at modest volume; check on phone speakers and earbuds, where most of our audience listens.

## 5. Loudness targets
| Output | Target |
|---|---|
| YouTube/streaming video | ≈ −14 LUFS integrated, true peak ≤ −1 dBTP |
| Shorts/TikTok/Reels | ≈ −14 LUFS, voice clearly on top |
| Podcasts/VO, affirmations | ≈ −16 LUFS, gentle compression |
| Sleep/relaxation tracks | Quieter and dynamic-stable (≈ −20 to −18 LUFS), no sudden peaks |
| Games | Mix in-engine to a consistent reference level; leave headroom; give players separate volume sliders |
Use `ffmpeg -af loudnorm` for batch normalisation.

## 6. Spatial / XR
3D sounds attenuate with distance; use HRTF spatialisation in XR; audio cues guide attention to off-screen events better than arrows.

## Checklist
- [ ] Asset list with triggers and priorities exists
- [ ] Frequent sounds have variations + random pitch
- [ ] Every player action has immediate audio feedback
- [ ] Music transitions on musical boundaries
- [ ] Mix referenced, high-passed, VO ducking in place
- [ ] Loudness measured against the target for the output
- [ ] Separate volume sliders (Music/SFX/VO) in games

## Sources
Collins, *Game Sound* (non-linearity, adaptive audio, diegesis). Marks, *The Complete Guide to Game Audio* (asset lists, pipeline, implementation). Viers, *The Sound Effects Bible* (recording, layering, naming). Senior, *Mixing Secrets for the Small Studio* (references, balance, EQ, monitoring). Loudness targets are standard platform norms. Summarised in our own words.
