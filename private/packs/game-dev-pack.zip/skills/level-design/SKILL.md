---
name: level-design
description: Design levels, worlds and spaces that guide players without signs, pace challenge and tell stories through architecture. Use when greyboxing levels, laying out 2D action-adventure worlds or metroidvanias, planning XR rooms, placing enemies, pickups and secrets, or fixing levels where players get lost or bored. Built from Christopher Totten (An Architectural Approach to Level Design; World Design for 2D Action-Adventures), with Scott Rogers' beat chart. Pairs with `game-design` and `game-feel-ux`.
metadata:
  version: 1.0.0
---

# Level design

## 1. Spaces communicate (Totten)
Architecture tells players where to go and how to feel before any text does.
- **Prospect and refuge:** players are drawn to places where they can see without being seen (high ground, cover) and feel exposed in open spaces. Use refuge for rest and planning, prospect for vistas and goals.
- **Landmarks and weenies:** one big, visible goal (a tower, a light) pulls players across a space. Every area needs one orienting landmark.
- **Light, colour and contrast guide the eye:** a lit doorway reads as "go here"; a consistent colour marks climbable or interactive surfaces (and is used for nothing else).
- **Narrow vs wide:** compressed corridors build tension; releasing into a wide space gives relief and awe.
- **Thresholds:** doors, arches and level changes mark "new area / new rules".

## 2. Teach, test, twist (pacing)
For each mechanic: **introduce** it safely → **develop** it with a small risk → **test** it under pressure → **twist** it by combining it with another mechanic. Map this across the game with a **beat chart** (rows = levels; columns = new mechanic, threats, reward, tension level, time, palette).
Alternate intensity: high-tension → breather → high-tension. Flat tension tires players out; constant breathers bore them.

## 3. Greybox first
- Build with primitives at final scale with the final **Three Cs** (character, camera, controls), and playtest before any art.
- Check **metrics**: jump height and distance, run speed, camera view; gaps and ledges are built from those numbers.
- Mark the **golden path** and count how long it takes. Add optional branches with rewards (secrets, lore, upgrades).

## 4. World design for 2D action-adventures (Totten)
- **Lock-and-key gating:** abilities, items or story events open new routes. Every lock should be **seen before its key** (the player remembers "I'll come back here").
- **Hub and spokes** or interlinked loops keep backtracking short. Add **shortcuts** that open from the far side.
- **Readable map:** distinct biomes by colour and silhouette; map screens show explored, unexplored and blocked.
- Reward exploration with something meaningful, never just currency.

## 5. XR rooms
- Design for **room-scale and seated**: key interactions within arm's reach; no required crouching or long walks.
- Comfort: teleport and snap turn options; no forced camera motion; horizon visible; avoid fast vertical motion.
- Scale matters more in VR: doors ~2 m, tables ~75 cm. Wrong scale breaks presence instantly.

## Checklist
- [ ] Each area has a landmark and a lit "go here" cue
- [ ] Every mechanic follows introduce → develop → test → twist
- [ ] Beat chart shows alternating intensity
- [ ] Greybox playtested at final metrics before art
- [ ] Locks are seen before keys; shortcuts cut backtracking

## Sources
Totten, *An Architectural Approach to Level Design* (prospect/refuge, landmarks, spatial emotion, thresholds) and *World Design for 2D Action-Adventures* (gating, hubs, shortcuts, maps); Rogers, *Level Up!* (beat chart). Summarised in our own words.
