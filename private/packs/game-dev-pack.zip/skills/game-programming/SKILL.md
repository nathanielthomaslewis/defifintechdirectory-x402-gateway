---
name: game-programming
description: Structure game code so it stays changeable and fast: game loop, update order, state machines, components, events, pooling, spatial partitioning, data-oriented layout, and engine architecture choices. Use when writing or reviewing Godot (GDScript/C#) or web game code, refactoring a tangled player controller, fixing frame spikes or GC stutter, or planning systems for av-game-kit / av-xr-kit. Built from Robert Nystrom (Game Programming Patterns) and Jason Gregory (Game Engine Architecture). Pairs with `game-design` and `game-feel-ux`.
metadata:
  version: 1.0.0
---

# Game programming

## 1. Patterns to reach for (Nystrom)
| Problem | Pattern | In Godot |
|---|---|---|
| Player/enemy with many modes and messy if-chains | **State** (finite state machine, or hierarchical/pushdown for "pause then resume") | A `State` node or resource per state; one active; `enter/exit/physics_update` |
| Undo, replays, rebinding, AI that issues the same actions | **Command** (actions as objects) | Input → Command objects → actor |
| Systems that must react without knowing each other | **Observer** / **Event Queue** (decoupled, possibly deferred) | Signals; an autoload event bus for cross-scene events; `call_deferred` for queueing |
| Many similar objects (trees, bullets, tiles) | **Flyweight** (share heavy data) + **Type Object** (data-driven kinds) | Shared `Resource`s; MultiMesh for many instances |
| Bullets, particles, pickups spawned and freed constantly | **Object Pool** | Pre-instantiate, hide and reuse; never `queue_free` per bullet |
| "Who's near me?" checks on many entities | **Spatial Partition** (grid, quadtree, BVH) | Area2D/3D groups, physics queries, or a custom grid |
| Logic per entity, mixed behaviours | **Component** | Child nodes or composition resources rather than deep inheritance |
| Expensive recomputation | **Dirty Flag** | Recompute derived data only when inputs change |
| Global services (audio, save) | **Service Locator** (not raw singletons everywhere) | One autoload facade; swap a null/debug service in tests |
| Cache-unfriendly hot loops | **Data Locality** | Packed arrays and servers APIs for thousands of items |
Avoid **Singleton** sprawl: every global is hidden coupling.

## 2. Game loop and time (Nystrom, Gregory)
- Gameplay physics in **fixed timestep** (`_physics_process`), visuals interpolated in `_process`. Never scale movement by a variable delta in physics code that must be deterministic.
- Define **update order** explicitly (input → AI → physics → animation → camera → UI) so systems don't read half-updated state.
- Keep frame time stable: profile first, then fix the biggest spike. Typical culprits are allocation in hot loops, per-frame node lookups, overlapping physics queries and shader compiles.

## 3. Architecture (Gregory)
- **Layers:** platform → core (math, memory, containers, logging) → resources/assets → gameplay foundations (entities, events, scripting) → game-specific code. Lower layers never depend on higher ones.
- **Data-driven:** tuning values, item and enemy definitions live in data (Resources/JSON), not code, so designers and agents can tune without recompiling.
- **Memory:** pool, preallocate, avoid per-frame allocation; load streaming content asynchronously.
- **Tooling pays back:** in-game debug draw, live tuning, replay or record of inputs, and a headless test mode (for example, a short automated headless run).

## 4. Implementation checks
- Give modules explicit interfaces; avoid reaching into another module's internal nodes.
- Give systems a repeatable test and use a fixed timestep where simulation needs determinism.
- Put shared state behind a documented service or event interface.

## Sources
Nystrom, *Game Programming Patterns* (command, flyweight, observer, prototype, state, double buffer, game loop, update method, component, event queue, service locator, data locality, dirty flag, object pool, spatial partition). Gregory, *Game Engine Architecture* (runtime layers, game loop and time, memory, resources, gameplay foundations). Summarised in our own words.
