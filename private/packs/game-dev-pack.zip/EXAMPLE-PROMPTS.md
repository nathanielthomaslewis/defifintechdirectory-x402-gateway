# Example prompts

Replace bracketed fields with your project details.

## One-sheet

Use game-design to draft a one-page concept for [GENRE] on [PLATFORM]. Include audience, core loop, controls, success state and first playtest.

## Feel pass

Use game-feel-ux to critique this movement spec: [SPEC]. Suggest measurable input, motion and feedback changes, then a playtest checklist.

## Level greybox

Use level-design to sketch three learning beats for [MECHANIC]. Include landmarks, gating, intensity and a greybox test.

## System design

Use game-programming to propose a small architecture for [FEATURE]. Include state ownership, update order, data flow and a deterministic test.

## XR comfort

Use xr-design to review [INTERACTION] for locomotion, comfort, spatial UI and seated use. State hardware assumptions.

## Audio plan

Use game-audio to create an event-to-sound list for [GAME LOOP], with variations, music transitions and mix priorities.

