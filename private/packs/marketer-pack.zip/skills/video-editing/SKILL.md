---
name: video-editing
description: Plan shots and cut video that holds attention: shot lists, framing, camera moves, continuity, cutting rhythm and visual structure for ads, pins, book trailers, YouTube, shorts and game trailers. Use when storyboarding, writing AI-video shot prompts, assembling clips in an editor or ffmpeg/Remotion pipeline, or diagnosing why a video loses viewers. Built from Walter Murch (In the Blink of an Eye), Steven Katz (Film Directing Shot by Shot), Joseph Mascelli (The Five C's of Cinematography) and Bruce Block (The Visual Story). Pairs with `story-structure` and `animation-vfx`.
metadata:
  version: 1.0.0
---

# Video editing and cinematography

## 1. Plan the shots (Katz, Mascelli)
Write a shot list before generating or filming: `# · shot size · angle · move · subject/action · duration · purpose`.
**Mascelli's five Cs:**
1. **Camera angle:** eye level = neutral; low = power; high = vulnerability; POV = identification.
2. **Continuity:** screen direction, eyelines, props and lighting match across cuts. Respect the **180° line**.
3. **Cutting:** plan coverage so every cut has a reason (see below).
4. **Close-ups:** save the tightest shots for the biggest emotional or product moments.
5. **Composition:** rule of thirds, lead room in the direction of looking/movement, depth (foreground-mid-background).
Shot size ladder: wide/establishing → medium → close → extreme close. Move in as intensity rises.

## 2. Visual structure (Block)
The basic visual components are **space, line, shape, tone, colour, movement and rhythm**. For each one decide where you use **contrast** (intensity rises) and **affinity** (calm). Build an intensity graph that follows the story: low affinity at the start, contrast peaking at the climax/CTA, affinity again at resolution.
Example: a calm, even-toned opening (affinity) → fast cuts, strong diagonals and saturated colour at the problem/peak (contrast) → soft, even light on the "after" image.

## 3. Where to cut (Murch's rule of six, weighted)
1. **Emotion** (51%): does the cut keep the feeling true?
2. **Story** (23%): does it move the story forward?
3. **Rhythm** (10%): is it at the right beat?
4. **Eye trace** (7%): is the viewer's eye where the next shot needs it?
5. **2D plane of screen** (5%): screen direction respected
6. **3D space** (4%): spatial continuity
If you must sacrifice one, sacrifice from the bottom. Murch also: cut on the blink, the moment a thought completes.

## 4. Short-form rules (our channels)
- Hook in **0-1.5 s**: motion, a face, or the result first. No logos or slow fades up front.
- A visual change every **1.5-3 s** in shorts/pins; slower (4-8 s) in calm/sleep content where affinity is the point.
- Burned-in captions, safe-zone aware (avoid the bottom 20% and right edge on TikTok/Reels).
- Cut on action and on beat; J-cuts/L-cuts (audio leads or trails the picture) to smooth transitions.
- End on one CTA card ≥2 s, with the product shot.

## 5. Review checklist
- [ ] Shot list written; each shot has a purpose
- [ ] 180° line and screen direction respected
- [ ] Hook lands in the first 1.5 s
- [ ] Intensity graph rises to the CTA/climax
- [ ] Every cut passes Murch's top three (emotion, story, rhythm)
- [ ] Captions inside safe zones; audio levels consistent (see `game-audio` mixing notes)

## Sources
Murch, *In the Blink of an Eye* (rule of six, the blink). Katz, *Film Directing Shot by Shot* (shot lists, coverage, staging). Mascelli, *The Five C's of Cinematography*. Block, *The Visual Story* (visual components, contrast/affinity, intensity graphs). Summarised in our own words.
