---
name: marketing-experiments
description: Design, run, read and log A/B and multivariate tests on pages, ads, emails and offers. Use when planning a split test, writing a hypothesis, choosing metrics, sizing samples, deciding when to stop, diagnosing a page's conversion problems, or writing up what a test taught us. Draws on MarketingExperiments/MECLABS, Kohavi, Tang & Xu (Trustworthy Online Controlled Experiments) and Goward (You Should Test That!).
metadata:
  version: 1.0.0
---

# Marketing experiments

A test exists to **learn something about the customer**, not to find a winning colour. Every test answers one research question, and every result (win, loss or flat) becomes a learning we can use elsewhere (MECLABS).

## 1. Diagnose before you test: the MECLABS conversion heuristic
Review motivation, the value proposition, incentive, friction and anxiety as a diagnostic checklist. The MECLABS model gives these factors different emphasis; use observed behaviour to choose what to test.
| Factor | Ask | Typical fixes |
|---|---|---|
| **m: motivation** of the visitor (the biggest weight) | Which traffic, which need, how urgent? Did the ad promise what the page delivers? | Match message to source; one audience per page; separate angle pages |
| **v: value proposition** (clarity and force) | Can a stranger say in 5 seconds why *this* is better for *them*? | Specific headline, proof, "only we" claims backed by facts |
| **i: incentive** | Is there a reason to act now that adds value (bonus, bundle)? | Genuine bonuses; never fake scarcity |
| **f: friction** | What makes it harder: steps, fields, choices, slow load, unclear next step? | One CTA, fewer fields, faster page, clear buttons |
| **a: anxiety** (the emotional cost of risk) | What worries them: payment, refund, quality, spam? | Refund line near the button, instant-download note, real sample pages |
Use it to **find** hypotheses: score each factor 1-5 for the page, then test the weakest.

Goward's **LIFT** model is the same idea in another form: value proposition is the engine, and relevance, clarity and urgency lift it while anxiety and distraction drag it down.

## 2. Hypothesis (one per test)
`Changing [element] into [variant] will lift [primary metric] for [audience/traffic], because [heuristic factor: why].`
Example: *Changing the CTA from "Get the guide and workbook" to "Start with one zone" will lift checkout starts for ADHD-angle Meta traffic, because it restates the visitor's goal (motivation/relevance) at the decision point.*
Each test also records: the **research question**, the treatment set, what we expect to learn if it **loses**, and the next test either way.

## 3. Metrics (Kohavi)
- **OEC (overall evaluation criterion):** the one metric the decision is made on. Choose a metric tied to the decision, such as checkout starts per visitor.
- **Driver metrics:** CTA clicks, scroll depth, add-to-cart.
- **Guardrail metrics** must not get worse: refund rate, page load time, bounce, complaint emails. A "win" that breaks a guardrail is a loss.
- Decide all metrics **before** launch, and never pick the metric that happened to win afterwards.

## 4. Trust checks before reading any result (Kohavi)
1. **Instrumentation:** events fire once, for every variant, on every device.
2. **A/A test** for each new setup: identical variants should produce false positives at roughly the chosen significance rate over many tests. Investigate unusual differences.
3. **SRM (sample ratio mismatch):** compare the observed split with the expected allocation using an appropriate SRM test; investigate a significant mismatch (bots, redirects, caching, a browser excluded). Results with SRM are untrustworthy.
4. **Validity threats** (MECLABS): history (a holiday, sale or outage mid-test), instrumentation change, selection (traffic mix changed by source or campaign), sampling distortion (stopping too early).

## 5. Sample size and stopping
- Fix the **minimum sample per variant** and the **minimum run time (≥7 full days, whole weeks)** before launch.
- **No peeking-and-stopping** on p-values; it inflates false wins. Pre-register the sample size, duration and decision rule; choose a statistical method suited to the test and report uncertainty.
- Expect **novelty/primacy effects**: a new design can spike and then fade. Check the effect is stable in the second week.
- Small budgets: test **big changes** (new value proposition, layout pattern) that can move the needle detectably. Tiny tweaks need traffic we don't have.

## 6. Reading results
- Report effect + interval, not just "winner". Flat results are learnings too ("the button colour doesn't matter for this audience; spend effort elsewhere").
- **Segment only by pre-registered segments** (traffic source, device). Slicing afterwards finds noise.
- Ship the winner as a **hypothesis for other books**, and re-test it there before assuming it transfers (motivation differs by audience).

## 7. Log every test (MECLABS discipline)
Keep one dated entry per test: ID · page · research question · hypothesis · variants (screenshots) · traffic and dates · result with interval · trust checks passed · **what we learned about the customer** · next test.

## Sources
MarketingExperiments / MECLABS Institute (conversion heuristic, research-question discipline, validity threats; published research). Kohavi, Tang & Xu, *Trustworthy Online Controlled Experiments* (OEC, guardrails, A/A, SRM, peeking, novelty). Goward, *You Should Test That!* (LIFT model, hypothesis structure). Summarised in our own words.
