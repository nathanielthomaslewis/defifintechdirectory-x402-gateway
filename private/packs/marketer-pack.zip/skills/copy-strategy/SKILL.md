---
name: copy-strategy
description: Decide WHAT to say before writing copy: how aware the buyer is, how many similar claims the market has already heard, which desire to channel, and which honest persuasion levers fit. Use before writing headlines, landing pages, ads, VSL scripts, emails or angle pages, and when a page's copy is clear but still doesn't sell. Built from Eugene Schwartz (Breakthrough Advertising), Cialdini's principles via Kenrick et al. (Six Degrees of Social Influence) and our MARKETING-PLAYBOOK. Use with the `copywriting` skill, which covers HOW to write it.
metadata:
  version: 1.0.0
---

# Copy strategy

Copy can't create desire; it **channels a desire that already exists** onto your product (Schwartz). Strategy is choosing which desire, at what level of awareness, against what competition.

## 1. Find the mass desire
- Name the existing want in the reader's own words ("I want to stop waking at 3am with leg cramps"), not the product feature.
- Rank by **urgency** (how much it hurts now), **staying power** (still there next month) and **scope** (how many people share it).
- The headline's first job is to **recognise and intensify** that desire, then point it at one path: our product.

## 2. Match the buyer's state of awareness (Schwartz)
| Level | The reader... | Headline leads with |
|---|---|---|
| **Most aware** | knows the product and wants it | the product name + offer/price |
| **Product aware** | knows it, isn't sure | proof, a new detail, a reason now |
| **Solution aware** | knows a fix exists, not ours | our mechanism and why it's different |
| **Problem aware** | feels the pain, no solution yet | the pain, sharply named, then the promise |
| **Unaware** | doesn't see the problem | a story, identity or curiosity; product appears later |
Most cold traffic to our books is **problem- or solution-aware**: lead with the pain or the mechanism, never the product name.

## 3. Match market sophistication (Schwartz)
How many similar claims has this reader already heard?
1. **First to market:** state the claim plainly ("A cleaning system for ADHD").
2. **Second wave:** enlarge the claim (more specific, faster, easier).
3. **Crowded:** introduce a **new mechanism** ("seven 15-minute zones with a hard stop").
4. **Saturated mechanisms:** improve the mechanism (simpler, more complete).
5. **Exhausted market:** sell **identity and experience** (who the reader becomes), not claims.
Most of our niches (sleep, ADHD, manifestation, money) are stage 3-5. Mechanism and identity beat bigger promises, and bigger promises would break our honesty rules anyway.

## 4. Persuasion levers, honestly (Cialdini via Kenrick)
| Lever | Honest use for us | Never |
|---|---|---|
| **Reciprocity** | Free sample pages, a free mini-tracker, useful blog posts | "Gifts" that are really bait |
| **Commitment/consistency** | Small first step (download the free page, take the 2-minute check) | Tricks that trap people into saying yes |
| **Social proof** | Only real reviews and real numbers, once we have them | Invented testimonials, counts or ratings |
| **Authority** | The method's sources and our process, shown plainly | Fake experts, "clinically proven" |
| **Liking** | Our voice: honest, warm, founder-built | Pretending to be a customer |
| **Scarcity** | Genuine limits only (launch bonus ends on a real date) | Fake timers, "only 3 left" for a PDF |
Kenrick's nuance: **scarcity makes people think harder about the argument.** It helps a strong offer and *hurts* a weak one. Fix the value proposition before adding urgency.

## 5. Strategy brief (fill in before any page or ad)
`Desire:` … `Awareness level:` … `Sophistication stage:` … `Mechanism (stage 3+):` … `Identity (stage 5):` … `Lead with:` … `Main objection and answer:` … `Proof we actually have:` … `Lever(s):` …
Then draft copy using the supplied evidence. Check claims, clarity and the required local advertising rules.

## Sources
Schwartz, *Breakthrough Advertising* (mass desire, awareness levels, market sophistication, headline strategy). Kenrick, Goldstein & Braver (eds.), *Six Degrees of Social Influence* (Cialdini's principles and later research, incl. scarcity × argument quality). Summarised in our own words.
