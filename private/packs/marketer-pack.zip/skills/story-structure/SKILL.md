---
name: story-structure
description: Structure stories for books, game narratives, video ads, VSLs, trailers and short-form scripts: premise, character want vs need, turning points, scene design, beat sheets and action sequences. Use when outlining fiction or children's books, writing a game's narrative arc or quests, scripting a 30-90 s ad or trailer, or fixing a story that feels flat. Built from Robert McKee (Story; Action), Blake Snyder (Save the Cat) and the copy skills' awareness model. Pairs with `video-editing`, `copy-strategy` and `game-design`.
metadata:
  version: 1.0.0
---

# Story structure

## 1. The core (McKee)
- A story is a sequence of **value changes**: something that matters (safety, love, freedom, money) turns from positive to negative or back. A scene where no value changes is a non-event; cut or rewrite it.
- **Controlling idea:** one sentence: *[value] wins/loses because [cause]*. Every scene serves it.
- **Want vs need:** the protagonist consciously wants X; the story reveals they need Y. The climax forces a choice between them.
- **The gap:** the character acts expecting one result; the world reacts differently. Progressively widening gaps = rising stakes.
- **True character** is revealed by choices under pressure, never by description.

## 2. Shape (McKee + Snyder)
| Beat (Save the Cat) | Rough position | Job |
|---|---|---|
| Opening image | 0-1% | Snapshot of the "before" world |
| Theme stated | 5% | Someone hints at what the hero needs |
| Set-up | 1-10% | Hero, flaws, stakes |
| Catalyst (inciting incident) | 10% | Life knocked out of balance |
| Debate | 10-20% | Should I? |
| Break into Two | 20% | Hero chooses the new world |
| B story | 22% | Relationship that carries the theme |
| Fun and games | 20-50% | The promise of the premise |
| Midpoint | 50% | False victory or false defeat; stakes rise |
| Bad guys close in | 50-75% | Pressure inside and out |
| All is lost / dark night | 75-80% | Lowest point, something "dies" |
| Break into Three | 80% | Insight (the need) found |
| Finale | 80-99% | Applies the lesson, changes the world |
| Final image | 100% | Mirror of the opening, showing change |
Use it as a diagnostic, not a formula.

## 3. Action stories (McKee, Action)
- The hero is defined by the **villain's power**; make the antagonist stronger, smarter and better resourced than the hero.
- Action needs a **victim** worth saving and a clear **MacGuffin** (what everyone fights over).
- Set-pieces escalate in scale and cost; each one changes the situation, never just repeats it.
- Reversals and surprise beat spectacle; the audience should see danger coming but not how the hero survives.

## 4. Short forms
- **Ad/VSL (30-90 s):** hook (the pain or a surprising image, 0-3 s) → turn (a new mechanism or insight) → proof → transformation (the "after" image) → one CTA. That's a micro story: before → catalyst → after.
- **Trailer:** world → disruption → escalating montage → button (title + one last beat).
- **Children's books:** one want, three tries that fail in rising ways (rule of three), a turn, a warm resolution; the child-hero solves it themselves.
- **Games:** narrative serves play. Quests are mini-arcs (want, obstacle, choice, change); let the player make the climactic choice (see `game-design`).

## 5. Scene check
For each scene: whose scene is it · what do they want · what blocks them · what value changes (+/−) · what's the turning point · how does it set up the next scene.

## Sources
McKee, *Story* (value change, controlling idea, gap, scene design, character) and *Action* (villain power, victim, set-piece escalation). Snyder, *Save the Cat!* (beat sheet). Summarised in our own words.
