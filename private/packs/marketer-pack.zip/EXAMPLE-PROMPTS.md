# Example prompts

Replace bracketed fields with your project details.

## Message brief

Use copy-strategy to write a strategy brief for [OFFER] and [AUDIENCE]. Identify awareness, likely desire, main objection and proof actually supplied. Flag gaps.

## Experiment plan

Use marketing-experiments to plan a test of [PAGE OR AD]. Give one research question, a hypothesis, primary metric, guardrails, sample plan and stopping rule. Do not claim a result.

## Story outline

Use story-structure to outline a 60-second explainer about [TOPIC] for [AUDIENCE]. Show the want, obstacle, turn and closing action.

## Edit review

Use video-editing to assess this shot list and transcript for pacing, clarity, screen direction, audio and caption safety. Return timecoded notes.

